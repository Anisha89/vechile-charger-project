import { Component, OnInit } from '@angular/core';
import { ChargingVehicle } from '../../../../models/charging-vehicle.model';
import { ChargingVehicleService } from '../../../admin/charging-vehicle/charging-vehicle.service';
import { AppContext } from '../../../../app.context';
import { Metric } from '../../../../models/metric.modal';
import { AlarmService } from '../../alarm/alarm.service';
import { Alarm } from '../../../../models/alarm.modal';
import { ChargingTerminal } from '../../../../models/charging-terminal.model';
import { ChargingTerminalService } from '../../../admin/charging-terminal/charging-terminal.service';

@Component({
    selector: 'app-asset-dashboard',
    templateUrl: './asset-dashboard.component.html',
    styleUrls: ['./asset-dashboard.component.scss']
})
export class AssetDashboardComponent implements OnInit {
    chargingVehicle: ChargingVehicle;
    chargingTerminals: ChargingTerminal[] = [];
    metrics: Metric[] = [];
    alarms: Alarm[] = [];
    zoom: 12;

    constructor(
        private context: AppContext,
        private chargingVehicleSerive: ChargingVehicleService,
        private chargingTerminalService: ChargingTerminalService,
        private alarmService: AlarmService
    ) {

    }
    ngOnInit() {
        this.chargingVehicle = this.context.getCopy('selected-chargingVehicle');
        if (this.chargingVehicle == null) {
            this.chargingVehicleSerive.get(this.chargingVehicleSerive.generateId(8)).subscribe(chargingVehicle => {
                this.chargingVehicle = chargingVehicle;
            });
        }
        this.initializeMetrics();
        this.initializeAlarms();
        this.intializeChargingTerminals();
    }

    intializeChargingTerminals() {
        this.chargingTerminalService.getByChargingVehicleId(this.chargingVehicle.id).subscribe(chargingTerminals => {
            this.chargingTerminals = chargingTerminals;
            console.log(chargingTerminals);
        });
    }

    initializeAlarms() {
        this.alarms = [];
        this.alarmService.getAll().subscribe(alarms => {
            this.alarms = alarms;
            /*for (let i = 0; i < alarms.length && i < 3; i++) {
                this.alarms.push(alarms[i]);
            }*/
        });
    }

    initializeMetrics() {
        const date = new Date();
        this.metrics = [
            {
                name: 'Ignition',
                value: 'Off',
                unit: '',
                lastUpdated: date,
                status: 'OK'
            },
            {
                name: 'Movement',
                value: 'Stopped',
                unit: '',
                lastUpdated: date,
                status: 'OK'
            },
            {
                name: 'Coolant temperature',
                value: '98.6',
                unit: 'F&deg;',
                lastUpdated: date,
                status: 'OK'
            },
            {
                name: 'Oil Pressure',
                value: '36',
                unit: 'psi',
                lastUpdated: date,
                status: 'OK'
            },
            {
                name: 'Coolant Level',
                value: '90',
                unit: '%',
                lastUpdated: date,
                status: 'OK'
            },
            {
                name: 'Fuel Level',
                value: '30',
                unit: '%',
                lastUpdated: date,
                status: 'OK'
            }
        ];
    }
}
