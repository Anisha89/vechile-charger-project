import { BaseValidator, ValidationSpec } from '../../../../services/base.validator';
import { Injectable } from '@angular/core';

@Injectable()
export class AssetDashboardValidatorNew extends BaseValidator {

    constructor() {
        super();
    }
}