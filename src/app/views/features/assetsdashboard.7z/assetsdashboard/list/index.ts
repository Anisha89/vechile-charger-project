export { AssetsDashboardComponentNew } from './assetsdashboard.component';
