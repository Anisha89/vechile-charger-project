export { AssetDashboardModuleNew } from './assetdashboard.module';
